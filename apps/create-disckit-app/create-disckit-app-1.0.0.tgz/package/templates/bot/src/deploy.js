// Run this once to register slash commands:
// node src/deploy.js

require("dotenv").config();

const { REST, Routes } = require("discord.js");
const path = require("path");
const fs   = require("fs");

const commands = [];
const commandsPath = path.join(__dirname, "commands");

for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith(".js"))) {
  const command = require(path.join(commandsPath, file));
  if (command.data) commands.push(command.data.toJSON());
}

const rest = new REST().setToken(process.env.BOT_TOKEN);

(async () => {
  try {
    console.log(`Registering ${commands.length} command(s)...`);

    // Deploy to test guild first (instant) — change to global when ready
    const guildId = process.env.TEST_GUILD_ID;
    if (guildId) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, guildId),
        { body: commands },
      );
      console.log(`✔  Registered to guild ${guildId}`);
    } else {
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands },
      );
      console.log("✔  Registered globally (may take up to 1 hour)");
    }
  } catch (error) {
    console.error(error);
  }
})();
