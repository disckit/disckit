require("dotenv").config();

const { Client, GatewayIntentBits, Collection } = require("discord.js");
const { CooldownManager } = require("@disckit/cooldown");
const { AntifloodManager } = require("@disckit/antiflood");
const path = require("path");
const fs   = require("fs");

// ── Client ────────────────────────────────────────────────────────────────────

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// ── Utilities ──────────────────────────────────────────────────────────────────

client.commands  = new Collection();
client.cooldowns = new CooldownManager({ default: 3000 });
client.antiflood = new AntifloodManager({
  globalRule: { windowMs: 5000, maxHits: 5, penaltyMode: "NONE" },
});

// ── Load commands ──────────────────────────────────────────────────────────────

const commandsPath = path.join(__dirname, "commands");
if (fs.existsSync(commandsPath)) {
  for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith(".js"))) {
    const command = require(path.join(commandsPath, file));
    if (command.data && command.execute) {
      client.commands.set(command.data.name, command);
    }
  }
}

// ── Events ─────────────────────────────────────────────────────────────────────

client.once("ready", () => {
  console.log(`✔  Logged in as ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  // Antiflood check
  const { isBlocked, formatRetryAfter } = require("@disckit/antiflood");
  const check = client.antiflood.check({
    userId:        interaction.user.id,
    guildId:       interaction.guildId ?? "*",
    commandName:   interaction.commandName,
    memberRoleIds: interaction.member?.roles?.cache?.map(r => r.id) ?? [],
  });

  if (isBlocked(check)) {
    return interaction.reply({
      content: `⏳ Devagar! Tente novamente em **${formatRetryAfter(check.retryAfterMs)}**.`,
      ephemeral: true,
    });
  }

  try {
    await command.execute(interaction, client);
  } catch (error) {
    console.error(error);
    const msg = { content: "Ocorreu um erro ao executar este comando.", ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(msg);
    } else {
      await interaction.reply(msg);
    }
  }
});

// ── Login ──────────────────────────────────────────────────────────────────────

if (!process.env.BOT_TOKEN) {
  console.error("✖  BOT_TOKEN não encontrado no .env");
  process.exit(1);
}

client.login(process.env.BOT_TOKEN);
