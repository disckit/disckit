const { SlashCommandBuilder } = require("discord.js");
const { formatTime } = require("@disckit/common");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Verifica a latência do bot."),

  async execute(interaction, client) {
    const latency    = Math.round(client.ws.ping);
    const uptime     = formatTime(Math.floor(client.uptime / 1000));

    await interaction.reply({
      embeds: [{
        color:  0x5865F2,
        title:  "🏓 Pong!",
        fields: [
          { name: "Latência",  value: `${latency}ms`, inline: true },
          { name: "Uptime",    value: uptime,          inline: true },
        ],
        timestamp: new Date().toISOString(),
      }],
    });
  },
};
