const { SlashCommandBuilder } = require("discord.js");
const { formatUptime, DISCORD } = require("@disckit/common");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("info")
    .setDescription("Informações sobre o servidor."),

  async execute(interaction) {
    const { guild } = interaction;
    if (!guild) return interaction.reply({ content: "Use em um servidor.", ephemeral: true });

    await interaction.reply({
      embeds: [{
        color:  0x5865F2,
        title:  guild.name,
        thumbnail: guild.iconURL() ? { url: guild.iconURL() } : undefined,
        fields: [
          { name: "Membros",   value: `${guild.memberCount}`,                       inline: true },
          { name: "Criado em", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
          { name: "ID",        value: `\`${guild.id}\``,                            inline: true },
        ],
        footer: { text: `Limite de fields: ${DISCORD.MAX_EMBED_FIELDS}` },
        timestamp: new Date().toISOString(),
      }],
    });
  },
};
