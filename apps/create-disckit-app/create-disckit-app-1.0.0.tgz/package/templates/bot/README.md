# {{PROJECT_NAME}}

A Discord bot built with [discord.js](https://discord.js.org) and [@disckit](https://github.com/disckit/disckit).

## Setup

1. Copy `.env.example` to `.env` and fill in your values
2. Install dependencies: `npm install`
3. Register slash commands: `node src/deploy.js`
4. Start the bot: `npm start`

## Structure

```
src/
  index.js       → bot entry point (client, cooldown, antiflood)
  deploy.js      → register slash commands
  commands/
    ping.js      → /ping — latency and uptime
    info.js      → /info — server information
```

## Included @disckit packages

- `@disckit/common` — `formatTime`, `DISCORD` constants, and more
- `@disckit/cooldown` — per-user command cooldowns
- `@disckit/antiflood` — sliding window rate limiter

## Dev mode

```sh
npm run dev   # node --watch (auto-restarts on file changes)
```
